package com.google.android.gms.internal;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    void a(d dVar, boolean z);
}
