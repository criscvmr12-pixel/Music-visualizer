package com.google.android.gms.a;

import android.os.IInterface;

/* JADX INFO: loaded from: classes.dex */
public interface a extends IInterface {
}
