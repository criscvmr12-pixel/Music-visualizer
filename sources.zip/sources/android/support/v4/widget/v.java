package android.support.v4.widget;

import android.support.v4.view.y;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class v {
    private static final Interpolator v = new w();
    private int a;
    private int b;
    private int c;
    private float[] d;
    private float[] e;
    private float[] f;
    private float[] g;
    private int[] h;
    private int[] i;
    private int[] j;
    private int k;
    private VelocityTracker l;
    private float m;
    private float n;
    private int o;
    private int p;
    private k q;
    private final x r;
    private View s;
    private boolean t;
    private final ViewGroup u;
    private final Runnable w;

    private float a(float f) {
        return (float) Math.sin((float) (((double) (f - 0.5f)) * 0.4712389167638204d));
    }

    private float a(float f, float f2, float f3) {
        float fAbs = Math.abs(f);
        if (fAbs < f2) {
            return 0.0f;
        }
        if (fAbs > f3) {
            return f <= 0.0f ? -f3 : f3;
        }
        return f;
    }

    private int a(int i, int i2, int i3) {
        if (i == 0) {
            return 0;
        }
        int width = this.u.getWidth();
        int i4 = width / 2;
        float fA = (a(Math.min(1.0f, Math.abs(i) / width)) * i4) + i4;
        int iAbs = Math.abs(i2);
        return Math.min(iAbs > 0 ? Math.round(Math.abs(fA / iAbs) * 1000.0f) * 4 : (int) (((Math.abs(i) / i3) + 1.0f) * 256.0f), 600);
    }

    private int a(View view, int i, int i2, int i3, int i4) {
        int iB = b(i3, (int) this.n, (int) this.m);
        int iB2 = b(i4, (int) this.n, (int) this.m);
        int iAbs = Math.abs(i);
        int iAbs2 = Math.abs(i2);
        int iAbs3 = Math.abs(iB);
        int iAbs4 = Math.abs(iB2);
        int i5 = iAbs3 + iAbs4;
        int i6 = iAbs + iAbs2;
        return (int) (((iB2 != 0 ? iAbs4 / i5 : iAbs2 / i6) * a(i2, iB2, this.r.b(view))) + ((iB != 0 ? iAbs3 / i5 : iAbs / i6) * a(i, iB, this.r.a(view))));
    }

    private void a(float f, float f2) {
        this.t = true;
        this.r.a(this.s, f, f2);
        this.t = false;
        if (this.a == 1) {
            c(0);
        }
    }

    private void a(float f, float f2, int i) {
        f(i);
        float[] fArr = this.d;
        this.f[i] = f;
        fArr[i] = f;
        float[] fArr2 = this.e;
        this.g[i] = f2;
        fArr2[i] = f2;
        this.h[i] = e((int) f, (int) f2);
        this.k |= 1 << i;
    }

    private boolean a(float f, float f2, int i, int i2) {
        float fAbs = Math.abs(f);
        float fAbs2 = Math.abs(f2);
        if ((this.h[i] & i2) != i2 || (this.p & i2) == 0 || (this.j[i] & i2) == i2 || (this.i[i] & i2) == i2) {
            return false;
        }
        if (fAbs <= this.b && fAbs2 <= this.b) {
            return false;
        }
        if (fAbs >= fAbs2 * 0.5f || !this.r.b(i2)) {
            return (this.i[i] & i2) == 0 && fAbs > ((float) this.b);
        }
        int[] iArr = this.j;
        iArr[i] = iArr[i] | i2;
        return false;
    }

    private boolean a(int i, int i2, int i3, int i4) {
        int left = this.s.getLeft();
        int top = this.s.getTop();
        int i5 = i - left;
        int i6 = i2 - top;
        if (i5 == 0 && i6 == 0) {
            this.q.g();
            c(0);
            return false;
        }
        this.q.a(left, top, i5, i6, a(this.s, i5, i6, i3, i4));
        c(2);
        return true;
    }

    private boolean a(View view, float f, float f2) {
        if (view == null) {
            return false;
        }
        boolean z = this.r.a(view) > 0;
        boolean z2 = this.r.b(view) > 0;
        if (z && z2) {
            return (f * f) + (f2 * f2) > ((float) (this.b * this.b));
        }
        if (z) {
            return Math.abs(f) > ((float) this.b);
        }
        return z2 && Math.abs(f2) > ((float) this.b);
    }

    private int b(int i, int i2, int i3) {
        int iAbs = Math.abs(i);
        if (iAbs < i2) {
            return 0;
        }
        if (iAbs > i3) {
            return i <= 0 ? -i3 : i3;
        }
        return i;
    }

    private void b(float f, float f2, int i) {
        int i2 = a(f, f2, i, 1) ? 1 : 0;
        if (a(f2, f, i, 4)) {
            i2 |= 4;
        }
        if (a(f, f2, i, 2)) {
            i2 |= 2;
        }
        if (a(f2, f, i, 8)) {
            i2 |= 8;
        }
        if (i2 != 0) {
            int[] iArr = this.i;
            iArr[i] = iArr[i] | i2;
            this.r.b(i2, i);
        }
    }

    private void b(int i, int i2, int i3, int i4) {
        int iA;
        int iB;
        int left = this.s.getLeft();
        int top = this.s.getTop();
        if (i3 != 0) {
            iA = this.r.a(this.s, i, i3);
            this.s.offsetLeftAndRight(iA - left);
        } else {
            iA = i;
        }
        if (i4 != 0) {
            iB = this.r.b(this.s, i2, i4);
            this.s.offsetTopAndBottom(iB - top);
        } else {
            iB = i2;
        }
        if (i3 == 0 && i4 == 0) {
            return;
        }
        this.r.a(this.s, iA, iB, iA - left, iB - top);
    }

    private void c(MotionEvent motionEvent) {
        int iC = android.support.v4.view.s.c(motionEvent);
        for (int i = 0; i < iC; i++) {
            int iB = android.support.v4.view.s.b(motionEvent, i);
            float fC = android.support.v4.view.s.c(motionEvent, i);
            float fD = android.support.v4.view.s.d(motionEvent, i);
            this.f[iB] = fC;
            this.g[iB] = fD;
        }
    }

    private int e(int i, int i2) {
        int i3 = i < this.u.getLeft() + this.o ? 1 : 0;
        if (i2 < this.u.getTop() + this.o) {
            i3 |= 4;
        }
        if (i > this.u.getRight() - this.o) {
            i3 |= 2;
        }
        return i2 > this.u.getBottom() - this.o ? i3 | 8 : i3;
    }

    private void e(int i) {
        if (this.d == null) {
            return;
        }
        this.d[i] = 0.0f;
        this.e[i] = 0.0f;
        this.f[i] = 0.0f;
        this.g[i] = 0.0f;
        this.h[i] = 0;
        this.i[i] = 0;
        this.j[i] = 0;
        this.k &= (1 << i) ^ (-1);
    }

    private void f(int i) {
        if (this.d == null || this.d.length <= i) {
            float[] fArr = new float[i + 1];
            float[] fArr2 = new float[i + 1];
            float[] fArr3 = new float[i + 1];
            float[] fArr4 = new float[i + 1];
            int[] iArr = new int[i + 1];
            int[] iArr2 = new int[i + 1];
            int[] iArr3 = new int[i + 1];
            if (this.d != null) {
                System.arraycopy(this.d, 0, fArr, 0, this.d.length);
                System.arraycopy(this.e, 0, fArr2, 0, this.e.length);
                System.arraycopy(this.f, 0, fArr3, 0, this.f.length);
                System.arraycopy(this.g, 0, fArr4, 0, this.g.length);
                System.arraycopy(this.h, 0, iArr, 0, this.h.length);
                System.arraycopy(this.i, 0, iArr2, 0, this.i.length);
                System.arraycopy(this.j, 0, iArr3, 0, this.j.length);
            }
            this.d = fArr;
            this.e = fArr2;
            this.f = fArr3;
            this.g = fArr4;
            this.h = iArr;
            this.i = iArr2;
            this.j = iArr3;
        }
    }

    private void g() {
        if (this.d == null) {
            return;
        }
        Arrays.fill(this.d, 0.0f);
        Arrays.fill(this.e, 0.0f);
        Arrays.fill(this.f, 0.0f);
        Arrays.fill(this.g, 0.0f);
        Arrays.fill(this.h, 0);
        Arrays.fill(this.i, 0);
        Arrays.fill(this.j, 0);
        this.k = 0;
    }

    private void h() {
        this.l.computeCurrentVelocity(1000, this.m);
        a(a(y.a(this.l, this.c), this.n, this.m), a(y.b(this.l, this.c), this.n, this.m));
    }

    public int a() {
        return this.a;
    }

    public void a(int i) {
        this.p = i;
    }

    public void a(View view, int i) {
        if (view.getParent() != this.u) {
            throw new IllegalArgumentException("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (" + this.u + ")");
        }
        this.s = view;
        this.c = i;
        this.r.b(view, i);
        c(1);
    }

    public boolean a(int i, int i2) {
        if (this.t) {
            return a(i, i2, (int) y.a(this.l, this.c), (int) y.b(this.l, this.c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    public boolean a(MotionEvent motionEvent) {
        View viewD;
        View viewD2;
        int iA = android.support.v4.view.s.a(motionEvent);
        int iB = android.support.v4.view.s.b(motionEvent);
        if (iA == 0) {
            e();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        switch (iA) {
            case 0:
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                int iB2 = android.support.v4.view.s.b(motionEvent, 0);
                a(x, y, iB2);
                View viewD3 = d((int) x, (int) y);
                if (viewD3 == this.s && this.a == 2) {
                    b(viewD3, iB2);
                }
                int i = this.h[iB2];
                if ((this.p & i) != 0) {
                    this.r.a(i & this.p, iB2);
                }
                break;
            case 1:
            case 3:
                e();
                break;
            case 2:
                int iC = android.support.v4.view.s.c(motionEvent);
                for (int i2 = 0; i2 < iC; i2++) {
                    int iB3 = android.support.v4.view.s.b(motionEvent, i2);
                    float fC = android.support.v4.view.s.c(motionEvent, i2);
                    float fD = android.support.v4.view.s.d(motionEvent, i2);
                    float f = fC - this.d[iB3];
                    float f2 = fD - this.e[iB3];
                    b(f, f2, iB3);
                    if (this.a == 1 || ((viewD = d((int) fC, (int) fD)) != null && a(viewD, f, f2) && b(viewD, iB3))) {
                        c(motionEvent);
                    }
                    break;
                }
                c(motionEvent);
                break;
            case 5:
                int iB4 = android.support.v4.view.s.b(motionEvent, iB);
                float fC2 = android.support.v4.view.s.c(motionEvent, iB);
                float fD2 = android.support.v4.view.s.d(motionEvent, iB);
                a(fC2, fD2, iB4);
                if (this.a == 0) {
                    int i3 = this.h[iB4];
                    if ((this.p & i3) != 0) {
                        this.r.a(i3 & this.p, iB4);
                    }
                } else if (this.a == 2 && (viewD2 = d((int) fC2, (int) fD2)) == this.s) {
                    b(viewD2, iB4);
                }
                break;
            case 6:
                e(android.support.v4.view.s.b(motionEvent, iB));
                break;
        }
        return this.a == 1;
    }

    public boolean a(View view, int i, int i2) {
        this.s = view;
        this.c = -1;
        return a(i, i2, 0, 0);
    }

    public boolean a(boolean z) {
        boolean zA;
        if (this.a == 2) {
            boolean zF = this.q.f();
            int iB = this.q.b();
            int iC = this.q.c();
            int left = iB - this.s.getLeft();
            int top = iC - this.s.getTop();
            if (left != 0) {
                this.s.offsetLeftAndRight(left);
            }
            if (top != 0) {
                this.s.offsetTopAndBottom(top);
            }
            if (left != 0 || top != 0) {
                this.r.a(this.s, iB, iC, left, top);
            }
            if (zF && iB == this.q.d() && iC == this.q.e()) {
                this.q.g();
                zA = this.q.a();
            } else {
                zA = zF;
            }
            if (!zA) {
                if (z) {
                    this.u.post(this.w);
                } else {
                    c(0);
                }
            }
        }
        return this.a == 2;
    }

    public int b() {
        return this.o;
    }

    public void b(MotionEvent motionEvent) {
        int i;
        int i2 = 0;
        int iA = android.support.v4.view.s.a(motionEvent);
        int iB = android.support.v4.view.s.b(motionEvent);
        if (iA == 0) {
            e();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        switch (iA) {
            case 0:
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                int iB2 = android.support.v4.view.s.b(motionEvent, 0);
                View viewD = d((int) x, (int) y);
                a(x, y, iB2);
                b(viewD, iB2);
                int i3 = this.h[iB2];
                if ((this.p & i3) != 0) {
                    this.r.a(i3 & this.p, iB2);
                }
                break;
            case 1:
                if (this.a == 1) {
                    h();
                }
                e();
                break;
            case 2:
                if (this.a != 1) {
                    int iC = android.support.v4.view.s.c(motionEvent);
                    while (i2 < iC) {
                        int iB3 = android.support.v4.view.s.b(motionEvent, i2);
                        float fC = android.support.v4.view.s.c(motionEvent, i2);
                        float fD = android.support.v4.view.s.d(motionEvent, i2);
                        float f = fC - this.d[iB3];
                        float f2 = fD - this.e[iB3];
                        b(f, f2, iB3);
                        if (this.a != 1) {
                            View viewD2 = d((int) fC, (int) fD);
                            if (!a(viewD2, f, f2) || !b(viewD2, iB3)) {
                                i2++;
                            }
                        }
                        c(motionEvent);
                        break;
                    }
                    c(motionEvent);
                } else {
                    int iA2 = android.support.v4.view.s.a(motionEvent, this.c);
                    float fC2 = android.support.v4.view.s.c(motionEvent, iA2);
                    float fD2 = android.support.v4.view.s.d(motionEvent, iA2);
                    int i4 = (int) (fC2 - this.f[this.c]);
                    int i5 = (int) (fD2 - this.g[this.c]);
                    b(this.s.getLeft() + i4, this.s.getTop() + i5, i4, i5);
                    c(motionEvent);
                }
                break;
            case 3:
                if (this.a == 1) {
                    a(0.0f, 0.0f);
                }
                e();
                break;
            case 5:
                int iB4 = android.support.v4.view.s.b(motionEvent, iB);
                float fC3 = android.support.v4.view.s.c(motionEvent, iB);
                float fD3 = android.support.v4.view.s.d(motionEvent, iB);
                a(fC3, fD3, iB4);
                if (this.a == 0) {
                    b(d((int) fC3, (int) fD3), iB4);
                    int i6 = this.h[iB4];
                    if ((this.p & i6) != 0) {
                        this.r.a(i6 & this.p, iB4);
                    }
                } else if (c((int) fC3, (int) fD3)) {
                    b(this.s, iB4);
                }
                break;
            case 6:
                int iB5 = android.support.v4.view.s.b(motionEvent, iB);
                if (this.a == 1 && iB5 == this.c) {
                    int iC2 = android.support.v4.view.s.c(motionEvent);
                    while (true) {
                        if (i2 >= iC2) {
                            i = -1;
                        } else {
                            int iB6 = android.support.v4.view.s.b(motionEvent, i2);
                            if (iB6 != this.c) {
                                if (d((int) android.support.v4.view.s.c(motionEvent, i2), (int) android.support.v4.view.s.d(motionEvent, i2)) == this.s && b(this.s, iB6)) {
                                    i = this.c;
                                }
                            }
                            i2++;
                        }
                    }
                    if (i == -1) {
                        h();
                    }
                }
                e(iB5);
                break;
        }
    }

    public boolean b(int i) {
        return (this.k & (1 << i)) != 0;
    }

    public boolean b(int i, int i2) {
        if (!b(i2)) {
            return false;
        }
        boolean z = (i & 1) == 1;
        boolean z2 = (i & 2) == 2;
        float f = this.f[i2] - this.d[i2];
        float f2 = this.g[i2] - this.e[i2];
        if (z && z2) {
            return (f * f) + (f2 * f2) > ((float) (this.b * this.b));
        }
        if (z) {
            return Math.abs(f) > ((float) this.b);
        }
        return z2 && Math.abs(f2) > ((float) this.b);
    }

    boolean b(View view, int i) {
        if (view == this.s && this.c == i) {
            return true;
        }
        if (view == null || !this.r.a(view, i)) {
            return false;
        }
        this.c = i;
        a(view, i);
        return true;
    }

    public boolean b(View view, int i, int i2) {
        return view != null && i >= view.getLeft() && i < view.getRight() && i2 >= view.getTop() && i2 < view.getBottom();
    }

    public View c() {
        return this.s;
    }

    void c(int i) {
        if (this.a != i) {
            this.a = i;
            this.r.a(i);
            if (i == 0) {
                this.s = null;
            }
        }
    }

    public boolean c(int i, int i2) {
        return b(this.s, i, i2);
    }

    public int d() {
        return this.b;
    }

    public View d(int i, int i2) {
        for (int childCount = this.u.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = this.u.getChildAt(this.r.c(childCount));
            if (i >= childAt.getLeft() && i < childAt.getRight() && i2 >= childAt.getTop() && i2 < childAt.getBottom()) {
                return childAt;
            }
        }
        return null;
    }

    public boolean d(int i) {
        int length = this.d.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (b(i, i2)) {
                return true;
            }
        }
        return false;
    }

    public void e() {
        this.c = -1;
        g();
        if (this.l != null) {
            this.l.recycle();
            this.l = null;
        }
    }

    public void f() {
        e();
        if (this.a == 2) {
            int iB = this.q.b();
            int iC = this.q.c();
            this.q.g();
            int iB2 = this.q.b();
            int iC2 = this.q.c();
            this.r.a(this.s, iB2, iC2, iB2 - iB, iC2 - iC);
        }
        c(0);
    }
}
