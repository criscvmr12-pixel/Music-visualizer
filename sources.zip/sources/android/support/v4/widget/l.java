package android.support.v4.widget;

/* JADX INFO: loaded from: classes.dex */
interface l {
    void a(Object obj, int i, int i2, int i3, int i4, int i5);

    boolean a(Object obj);

    int b(Object obj);

    int c(Object obj);

    boolean d(Object obj);

    void e(Object obj);

    int f(Object obj);

    int g(Object obj);
}
