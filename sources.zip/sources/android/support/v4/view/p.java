package android.support.v4.view;

import android.view.KeyEvent;

/* JADX INFO: loaded from: classes.dex */
interface p {
    void a(KeyEvent keyEvent);

    boolean a(int i, int i2);

    boolean b(int i);
}
