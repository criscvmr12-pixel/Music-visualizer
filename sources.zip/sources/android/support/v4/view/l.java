package android.support.v4.view;

import android.os.Build;
import android.view.KeyEvent;

/* JADX INFO: loaded from: classes.dex */
public class l {
    static final p a;

    static {
        if (Build.VERSION.SDK_INT >= 11) {
            a = new o();
        } else {
            a = new m();
        }
    }

    public static boolean a(KeyEvent keyEvent) {
        return a.b(keyEvent.getMetaState());
    }

    public static boolean a(KeyEvent keyEvent, int i) {
        return a.a(keyEvent.getMetaState(), i);
    }

    public static void b(KeyEvent keyEvent) {
        a.a(keyEvent);
    }
}
