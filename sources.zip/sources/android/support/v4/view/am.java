package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
interface am {
    int a(View view);

    void a(View view, int i, int i2, int i3, int i4);

    void a(View view, int i, Paint paint);

    void a(View view, Paint paint);

    void a(View view, a aVar);

    void a(View view, Runnable runnable);

    boolean a(View view, int i);

    void b(View view);

    void b(View view, int i);

    int c(View view);

    int d(View view);

    boolean e(View view);
}
