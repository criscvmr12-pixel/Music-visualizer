package android.support.v4.view;

import android.view.VelocityTracker;

/* JADX INFO: loaded from: classes.dex */
interface ab {
    float a(VelocityTracker velocityTracker, int i);

    float b(VelocityTracker velocityTracker, int i);
}
